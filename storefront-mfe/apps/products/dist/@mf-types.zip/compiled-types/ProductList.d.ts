export default function ProductList(): import("react/jsx-runtime").JSX.Element;
